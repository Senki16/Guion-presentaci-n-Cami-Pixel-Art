import base64, pathlib, html

BASE = pathlib.Path('/tmp')

def uri(p):
    return "data:image/png;base64," + base64.b64encode(pathlib.Path(p).read_bytes()).decode()

AV = {
    'dilan':   uri('/tmp/av/a0.png'),
    'valeria': uri('/tmp/av/a1.png'),
    'samuel':  uri('/tmp/av/a2.png'),
    'camila':  uri('/tmp/av/a3.png'),
    'leimar':  uri('/tmp/av/a4.png'),
}

from content import PEOPLE, BLOQUES, ORDEN

# ---------------------------------------------------------------- render
roster = ''.join(
    f'<button class="who" data-goto="{"b1" if k=="dilan" else {"samuel":"b2","valeria":"b3","leimar":"b5","camila":"b6"}[k]}">'
    f'<img src="{AV[k]}" alt="{n}"><b>{n}</b><span>{t}</span></button>'
    for k, n, t in PEOPLE
)

integrantes_cards = []
for k, n, t in PEOPLE:
    bloques = [b for b in BLOQUES if b['who'] == k]
    lista = ''.join(f'<span class="sl">{sec["n"]} · {sec["slide"]}</span>' for b in bloques for sec in b['sections'])
    turnos = ' · '.join(f'turno {i+1}' for i, b in enumerate(BLOQUES) if b['who'] == k)
    integrantes_cards.append(f"""
    <div class="card">
      <div class="head px" style="box-shadow:none;border-radius:10px">
        <img src="{AV[k]}" alt="{n}">
        <div class="t">
          <div class="name">{n}</div>
          <div class="topic">{t}</div>
        </div>
        <span class="chip gold">{turnos.upper()}</span>
      </div>
      <div class="slidebar" style="border:4px solid var(--line);border-top:0;border-radius:0 0 10px 10px;box-shadow:0 6px 0 rgba(0,0,0,.3)">
        <b>DIAPOSITIVAS</b>{lista}
      </div>
    </div>""")

guion_cards = []
for b in BLOQUES:
    nums = [s['n'] for s in b['sections']]
    rango = f"{nums[0].split('–')[0]}–{nums[-1]}" if len(nums) > 1 else nums[0]
    slides = ''.join(f'<span class="sl">{s["n"]} · {s["slide"]}</span>' for s in b['sections'])
    part = f'<span class="chip">{b["part"]}</span>' if b['part'] else ''
    secs = ''.join(f"""
        <div class="sec">
          <div class="sechead">
            <span class="dnum">DIAP. {s['n']}</span>
            <span class="dname">{s['slide']}</span>
          </div>
          <p class="cue">▸ {s['cue']}</p>
          {s['html'].strip()}
        </div>""" for s in b['sections'])
    guion_cards.append(f"""
    <div class="card" id="{b['id']}">
      <div class="head">
        <img src="{AV[b['who']]}" alt="{b['name']}">
        <div class="t">
          <div class="name">{b['name']}</div>
          <div class="topic">{b['topic']}</div>
        </div>
        {part}
        <span class="chip gold">{b['time']}</span>
      </div>
      <div class="slidebar"><b>DIAPOSITIVAS</b>{slides}</div>
      <div class="body">
        {secs}
        <div class="note"><span class="nt">NOTA PARA TI</span>{b['note']}</div>
        <div class="pdfbar">
          <button class="pdfbtn" data-card="{b['id']}">DESCARGAR ESTE GUION EN PDF</button>
          <span>Se abre la ventana de impresión: en “Destino” elige <b>Guardar como PDF</b>.</span>
        </div>
      </div>
    </div>""")

orden_html = ''.join(f"""
      <div class="step">
        <div class="num">{n}</div>
        <div class="box">
          <span class="time">{tm}</span>
          <h4>{who}</h4>
          <p>{what}<br><span style="color:#8a7a5c;font-size:13px">{dias}</span></p>
        </div>
      </div>""" for n, who, what, dias, tm in ORDEN)

jump = ''.join(
    f'<button data-goto="{x["id"]}">{x["name"]}{" ①" if x["id"]=="b1" else (" ②" if x["id"]=="b4" else "")}</button>'
    for x in BLOQUES)

tpl = pathlib.Path('/tmp/build/page.template.html').read_text(encoding='utf-8')
out = (tpl
       .replace('{{TITULO}}', uri('/mnt/user-data/uploads/spritesheet guion/titulo.png'))
       .replace('{{B_INICIO}}', uri('/tmp/btn/inicio.png'))
       .replace('{{B_INTEGRANTES}}', uri('/tmp/btn/integrantes.png'))
       .replace('{{B_GUION}}', uri('/tmp/btn/guion.png'))
       .replace('{{B_ORDEN}}', uri('/tmp/btn/orden.png'))
       .replace('{{ROSTER}}', roster)
       .replace('{{JUMP}}', jump)
       .replace('{{INTEGRANTES}}', ''.join(integrantes_cards))
       .replace('{{GUION}}', ''.join(guion_cards))
       .replace('{{ORDEN}}', orden_html))

dest = pathlib.Path('/home/claude/guion-presentacion.html')
dest.write_text(out, encoding='utf-8')
print(dest, round(len(out)/1024), 'KB')
