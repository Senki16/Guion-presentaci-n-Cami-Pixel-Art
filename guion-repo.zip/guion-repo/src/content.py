# -*- coding: utf-8 -*-
"""Contenido de los guiones, separado por diapositiva."""

PEOPLE = [
    ('dilan',   'DILAN',   'Presentación del hito e impacto'),
    ('samuel',  'SAMUEL',  'Contexto y desarrollo'),
    ('valeria', 'VALERIA', 'Protagonistas y desarrollo'),
    ('camila',  'CAMILA',  'Legado'),
    ('leimar',  'LEIMAR',  'Importancia y cierre'),
]

BLOQUES = [

# ══════════════════════════════════════════════════════ 1 · DILAN
dict(id='b1', who='dilan', name='DILAN', part='Bloque 1 de 2',
     topic='Presentación del hito · apertura', time='≈ 1 min',
     note="<b>Abres tú</b>: espera a que el salón esté callado y di la primera frase mirando al público, "
          "no a la pantalla. Por si preguntan: la escritura también surgió por su cuenta en China, "
          "Mesoamérica y Egipto; la de Mesopotamia es la más antigua con pruebas.",
     sections=[
       dict(n='1–2', slide='Portada + sección 01 “Presentación del hito”', cue='Mientras aparece la portada y pasas a la diapositiva morada',
            html="""
<p>Buenos días. Hoy vamos a hablar de uno de los hitos más importantes de la humanidad:
<strong>el nacimiento de la escritura</strong>, en Mesopotamia, hacia el <strong>3300 antes de Cristo</strong>.</p>
"""),
       dict(n='3', slide='¿Qué es la escritura?', cue='Los tres recuadros de colores: cuentas · fin de la prehistoria · cuneiforme',
            html="""
<p>La escritura es <strong>el primer sistema capaz de guardar la palabra fuera de la memoria humana</strong>.
<span class="opt">Antes de ella, todo lo que una sociedad sabía tenía que vivir en la cabeza de alguien.</span></p>

<p>Y no nació para escribir poemas: nació en Sumeria para <strong>llevar cuentas</strong>. Las primeras
tablillas dicen cuánto grano entró al templo y quién lo entregó, nada más.</p>

<p>Ese gesto tan práctico marca además <strong>el fin de la prehistoria</strong><span class="opt"> —que es
justamente el tiempo del que no tenemos nada escrito—</span>, y con los años esos signos dibujados se
simplificaron hasta convertirse en la <strong>escritura cuneiforme</strong>.</p>
"""),
       dict(n='4', slide='Antes y después del hito', cue='Señala el recuadro blanco (ANTES) y luego el oscuro (DESPUÉS)',
            html="""
<p><strong>Antes</strong>, la información dependía de la memoria y de la palabra: si nadie la recordaba,
se perdía. <strong>Después</strong>, quedó registrada y se pudo consultar generaciones más tarde.</p>

<p>Ese es el hito. <span class="pause">Ahora mis compañeros les cuentan dónde, cuándo y cómo ocurrió.</span></p>
"""),
     ]),

# ══════════════════════════════════════════════════════ 2 · SAMUEL
dict(id='b2', who='samuel', name='SAMUEL', part='',
     topic='Contexto histórico · por qué allí y entonces · qué escribían', time='≈ 2 min',
     note="El dato de “9 de cada 10 tablillas” es el que mejor se queda en la cabeza del público: dilo "
          "despacio y haz una pequeña pausa después.",
     sections=[
       dict(n='5', slide='Sección 02 “Contexto, protagonistas y desarrollo”', cue='Diapositiva verde de transición',
            html="""
<p>Ya sabemos qué fue el hito. Ahora vamos a ver <strong>dónde y cuándo ocurrió, quiénes lo hicieron y
cómo llegaron hasta ahí</strong>.</p>
"""),
       dict(n='6', slide='Contexto histórico', cue='A la izquierda está la tabla de números arcaicos del periodo Uruk',
            html="""
<p>Para entender por qué la escritura aparece justo ahí, hay que mirar el lugar. Estamos en
<strong>Mesopotamia</strong>, la región entre los ríos <strong>Tigris y Éufrates</strong>, en lo que hoy es Irak.</p>

<p>En ese momento las ciudades estaban creciendo y la agricultura producía más alimento del que una
persona podía controlar de memoria. <strong>Uruk</strong>, por ejemplo, reunía miles de habitantes, templos,
almacenes y sistemas de tributos. Había que saber cuánto se producía, quién lo recibía y qué se debía.
La memoria ya no era suficiente: <strong>hacía falta dejar un registro</strong>.</p>
"""),
       dict(n='7', slide='¿Por qué allí y entonces?', cue='Tres tarjetas: I Excedente · II Ciudad · III Arcilla',
            html="""
<p>Pero, ¿por qué allí y por qué entonces? Se juntaron tres condiciones.</p>

<p><strong>Primero, el excedente.</strong> Había más grano del que se consumía, y eso obliga a registrar
cuánto hay y a quién pertenece.</p>

<p><strong>Segundo, la ciudad.</strong> Miles de personas conviviendo y comerciando entre desconocidos.
La confianza tenía que convertirse en comprobantes.</p>

<p><strong>Y tercero, la arcilla.</strong> Era abundante, barata y duradera: el material perfecto para
conservar un registro. Sin algo tan simple como el barro, hoy probablemente no conservaríamos nada.</p>
"""),
       dict(n='8', slide='¿Qué escribían?', cue='Las cuatro ramas del esquema y el dato del recuadro punteado',
            html="""
<p>¿Y qué escribían exactamente? Recibos de <strong>grano, cerveza y ganado</strong>; raciones de los
<strong>trabajadores del templo</strong>; contratos de <strong>compraventa y préstamos</strong>; y mucho
después, listas de <strong>reyes, mitos y poemas</strong>.</p>

<p>De hecho, hay un dato que lo resume todo: <strong>nueve de cada diez tablillas conservadas son documentos
administrativos</strong>. La escritura no nació como arte; nació como contabilidad.
<span class="pause">Valeria les va a contar quiénes estuvieron detrás de todo esto.</span></p>
"""),
     ]),

# ══════════════════════════════════════════════════════ 3 · VALERIA
dict(id='b3', who='valeria', name='VALERIA', part='',
     topic='Protagonistas · la edubba · desarrollo del sistema', time='≈ 2 min',
     note="Los cuatro pasos van con la línea de tiempo de la diapositiva: señálalos con la mano mientras "
          "los enumeras, uno por uno. “Edubba” se pronuncia e-DU-ba.",
     sections=[
       dict(n='9', slide='Protagonistas', cue='Tres tarjetas: los sumerios · los escribas · templos y palacios',
            html="""
<p>Ahora, ¿quiénes hicieron esto posible? Aquí hay algo importante: <strong>no hubo un único inventor</strong>.
La escritura nació de una necesidad colectiva.</p>

<p>Los primeros son <strong>los sumerios</strong>, que construyeron las primeras grandes ciudades de
Mesopotamia y desarrollaron los primeros sistemas de signos. Después están <strong>los escribas</strong>,
que dominaron esos signos y se formaron durante años. Y por último, <strong>los templos y palacios</strong>,
que necesitaban controlar cuentas, tributos y recursos: fueron ellos quienes impulsaron y sostuvieron
el uso de la escritura.</p>
"""),
       dict(n='10', slide='La casa de las tablillas · edubba', cue='Los tres recuadros de colores, junto a la portada de revista',
            html="""
<p>Los escribas se formaban en la <strong>edubba</strong>, que significa literalmente
<strong>“la casa de las tablillas”</strong>: la escuela del templo donde se aprendía a escribir. Allí se
copiaban listas y signos miles de veces sobre arcilla húmeda, que podía alisarse y reutilizarse.
Y saber escribir <strong>era un privilegio</strong>: muy pocas personas accedían a esa formación.</p>
"""),
       dict(n='11', slide='Desarrollo', cue='Los cuatro pasos: 01 fichas · 02 pictogramas · 03 cuñas · 04 sonidos',
            html="""
<p>¿Y cómo se llegó al sistema? En cuatro pasos.</p>

<p><strong>Uno, las fichas.</strong> Primero se usaron fichas de barro para representar mercancías y cantidades.</p>

<p><strong>Dos, los pictogramas.</strong> Después, los dibujos empezaron a representar directamente aquello que
se quería registrar: un grano, un buey, una cabeza.</p>

<p><strong>Tres, las cuñas.</strong> Los dibujos se simplificaron y comenzaron a hacerse con una caña sobre la
arcilla; así surgieron los signos cuneiformes.</p>

<p><strong>Y cuatro, los sonidos.</strong> Con el tiempo, los signos dejaron de representar únicamente objetos
y empezaron a representar sonidos.</p>

<p>Ese último paso es el decisivo: <strong>la escritura pasó de representar cosas a representar ideas y
sonidos</strong>. Desde ese momento se puede escribir cualquier cosa que se pueda decir.
<span class="pause">Y con eso en la mano, Dilan nos cuenta qué cambió en el mundo.</span></p>
"""),
     ]),

# ══════════════════════════════════════════════════════ 4 · DILAN
dict(id='b4', who='dilan', name='DILAN', part='Bloque 2 de 2',
     topic='Impacto · impacto en el tiempo', time='≈ 1 min',
     note="<b>Pausa</b> antes de “con esas tablillas en la mano”: marca que empieza una parte nueva. "
          "En la línea de tiempo <b>señala con la mano</b>; si la miras, la lees. Gilgamesh, por si "
          "preguntan: más de mil años anterior a La Odisea.",
     sections=[
       dict(n='12', slide='Sección 03 “Impacto”', cue='Diapositiva lila de transición',
            html="""
<p>Con esas tablillas en la mano, <strong>¿qué cambió en el mundo?</strong></p>
"""),
       dict(n='13', slide='Impacto', cue='Los cuatro recuadros alrededor de la tablilla: ESTADO · LEY · SABER · LITERATURA',
            html="""
<p>La escritura convirtió la información en algo que podía <strong>conservarse, comprobarse y
transmitirse</strong>. Y eso cambió cuatro cosas.</p>

<p><strong>El Estado</strong>: con impuestos, contratos y censos se pudieron administrar territorios mucho
más grandes de lo que un funcionario podía recordar.</p>

<p><strong>La ley</strong>: las normas quedaron escritas, iguales para todos y se podían consultar.</p>

<p><strong>El saber</strong>: el conocimiento pudo pasar de una generación a otra <span class="opt">sin
depender de que alguien lo memorizara</span>.</p>

<p><strong>Y la literatura</strong>: mitos y poemas sobrevivieron por escrito, como la
<strong>Epopeya de Gilgamesh</strong>.</p>

<p>En resumen: dejar de depender de la memoria <strong>cambió la forma de organizar una sociedad</strong>.</p>
"""),
       dict(n='14', slide='Impacto en el tiempo', cue='Recórrela con la mano de un solo trazo, sin detenerte en cada fecha',
            html="""
<p>Y eso siguió pasando hasta hoy: de las tablillas de Uruk a los alfabetos, la imprenta y la lectura
digital. <span class="opt">Cada vez que cambió el soporte, la escritura se volvió más fácil de compartir.</span>
<strong>La lectura evoluciona, pero su esencia permanece.</strong>
<span class="pause">Camila nos cuenta qué nos dejó la escritura.</span></p>
"""),
     ]),

# ══════════════════════════════════════════════════════ 5 · CAMILA
dict(id='b6', who='camila', name='CAMILA', part='',
     topic='Legado', time='≈ 2 min',
     note="El párrafo del Hangul es el más largo de toda la presentación: pártelo en tres respiros — "
          "(1) antes usaban caracteres chinos, (2) por eso el rey Sejong creó un sistema propio, "
          "(3) sirvió para preservar la lengua y la identidad coreanas. Se pronuncian "
          "<b>Choson</b> (Joseon) y <b>Seyong</b> (Sejong). Si vas con el tiempo justo, di solo 1443 y "
          "omite el 1446.",
     sections=[
       dict(n='15', slide='Sección 04 “Importancia y legado”', cue='Diapositiva amarilla de transición (aparecen tu nombre y el de Leimar)',
            html="""
<p>Ya vimos cómo nació la escritura y qué cambió con ella. Ahora vamos a ver
<strong>qué nos dejó y por qué nos sigue importando hoy</strong>.</p>
"""),
       dict(n='16', slide='Legado', cue='Las cuatro columnas: memoria · conocimiento · identidad · comunicación',
            html="""
<p>“Para terminar, queremos preguntarnos: <strong>¿qué nos dejó la escritura y por qué sigue siendo
importante miles de años después?</strong>”</p>

<p>Primero, tenemos una <strong>memoria que perdura</strong>. Un ejemplo sencillo es <strong>La Odisea</strong>,
atribuida a Homero. Aunque nació dentro de una tradición oral, al ser puesta por escrito pudo conservarse
durante siglos y llegar hasta nosotros. Hoy todavía podemos leer una historia creada hace más de dos mil años.</p>

<p>El segundo punto es el <strong>conocimiento acumulado</strong>. La escritura permitió que las personas no
tuvieran que empezar desde cero. Los conocimientos de matemáticas, astronomía o medicina podían registrarse
y luego ser estudiados y desarrollados por otras generaciones.</p>

<p>Después está la <strong>identidad y la cultura</strong>. Un ejemplo muy claro es el <strong>Hangul</strong>.
Durante la dinastía Joseon, los coreanos utilizaban principalmente caracteres chinos para escribir, pero
estos pertenecían a un sistema muy complejo, con miles de caracteres, y no estaban diseñados específicamente
para la lengua coreana. Por eso, el <strong>rey Sejong</strong> impulsó la creación de un sistema propio: el
Hangul, desarrollado en <strong>1443</strong> y promulgado en <strong>1446</strong>. Esto fue importante porque
el Hangul permitió representar de manera mucho más directa la lengua que hablaba la población coreana. Por eso
no fue simplemente una nueva forma de escribir: ayudó a preservar y expresar una lengua y una identidad
cultural propias.</p>

<p>Finalmente, tenemos la <strong>comunicación sin límites</strong>. Antes, una carta podía tardar semanas o
meses en llegar a otro lugar. Hoy podemos escribir un mensaje y hacerlo llegar en segundos a alguien al otro
lado del mundo.</p>

<p>Entonces, el legado de la escritura no está solamente en las primeras tablillas. Está en nuestra capacidad
de <strong>conservar el pasado, acumular conocimiento, expresar nuestra identidad y comunicarnos con otros</strong>.
En otras palabras: <strong>cambiaron los soportes, pero la necesidad de dejar nuestras ideas para quienes vienen
después permanece</strong>. <span class="pause">Leimar cierra explicando por qué todo esto sigue siendo tan importante.</span></p>
"""),
     ]),

# ══════════════════════════════════════════════════════ 6 · LEIMAR
dict(id='b5', who='leimar', name='LEIMAR', part='',
     topic='Importancia · cierre', time='≈ 2 min',
     note="Cierras la presentación, así que la última frase es tuya: dila mirando al público, no a la "
          "pantalla, y espera un segundo antes del “gracias”. Tu bloque va después del de Camila y toca "
          "ideas parecidas: ella dio los <b>ejemplos</b> (La Odisea, el Hangul), tú das el <b>porqué</b>. "
          "Quédate con cuatro palabras: conserva, organiza, enseña, conecta.",
     sections=[
       dict(n='17', slide='Importancia', cue='Las cuatro columnas: conserva · organiza · impulsa · comunica',
            html="""
<p>Ese legado se puede resumir en una idea: la escritura transformó la manera en que
<strong>vivimos, organizamos y pensamos</strong>. Y lo hizo en cuatro sentidos.</p>

<p><strong>Primero, conserva el conocimiento.</strong> Permite guardar ideas, experiencias e información
para que sobrevivan al tiempo y a quienes las crearon. Una idea escrita puede durar mucho más que la
persona que la pensó.</p>

<p><strong>Segundo, organiza sociedades.</strong> Hace posibles las leyes, los contratos, los registros y
los sistemas que permiten coordinar y construir comunidades complejas. Una ciudad de miles de personas
no se sostiene solo con acuerdos de palabra.</p>

<p><strong>Tercero, impulsa el aprendizaje.</strong> Facilita enseñar, estudiar y acumular conocimiento de
generación en generación, y eso acelera el progreso: cada generación empieza donde terminó la anterior,
y no desde cero.</p>

<p><strong>Y cuarto, comunica sin límites.</strong> Conecta personas, culturas e ideas, y nos permite
comprender otras realidades y construir nuevos mundos.</p>

<p>Si lo pensamos bien, <strong>sin escritura muchas de las cosas que hoy damos por sentadas simplemente no
existirían</strong>: las leyes, los colegios, los libros, los mensajes que enviamos todos los días.</p>

<p>Por eso decimos que la escritura no solo registró la historia: <strong>también hizo posible que el
conocimiento siguiera vivo</strong>.</p>
"""),
       dict(n='18', slide='Gracias por escucharnos', cue='Diapositiva de cierre · mira al público',
            html="""
<p><span class="pause">De la arcilla a la pantalla, las ideas siguen escribiéndose. Gracias por escucharnos.</span></p>
"""),
     ]),
]

ORDEN = [
    ('1', 'DILAN',   'Portada · ¿Qué es la escritura? · Antes y después', 'Diapositivas 1–4',  '≈1:00'),
    ('2', 'SAMUEL',  'Contexto histórico · ¿Por qué allí y entonces? · ¿Qué escribían?', 'Diapositivas 5–8', '≈2:00'),
    ('3', 'VALERIA', 'Protagonistas · La casa de las tablillas · Desarrollo', 'Diapositivas 9–11', '≈2:00'),
    ('4', 'DILAN',   'Impacto · Impacto en el tiempo', 'Diapositivas 12–14', '≈1:00'),
    ('5', 'CAMILA',  'Sección 04 · Legado', 'Diapositivas 15–16', '≈2:00'),
    ('6', 'LEIMAR',  'Importancia · Cierre y agradecimiento', 'Diapositivas 17–18', '≈2:00'),
]
