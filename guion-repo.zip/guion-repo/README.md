# Guion de presentación — El nacimiento de la escritura

Página web con el guion de la exposición **"El nacimiento de la escritura"** (Mesopotamia, ~3300 a. C.),
separado por integrante y por diapositiva, con estética pixel art.

👉 **[Abrir la página](index.html)** — es un solo archivo HTML, se puede abrir con doble clic.

## Qué contiene

La página tiene cuatro pestañas:

| Pestaña | Para qué sirve |
|---|---|
| **Inicio** | Resumen de la presentación y quién habla de qué |
| **Integrantes** | Cada persona con las diapositivas que le tocan |
| **Guion** | El guion completo, dividido diapositiva por diapositiva |
| **Orden** | Orden de participación y tiempos |

Cada guion incluye:

- La **etiqueta de la diapositiva** (`DIAP. 9 · Protagonistas`), numeradas 1–18 igual que el PPT.
- Una indicación en cursiva de **qué está viendo el público** en ese momento.
- Las **frases de relevo** en rojo, para que el cambio de turno no quede en silencio.
- Las **frases opcionales en gris**: se pueden saltar si el tiempo va justo.
- Una **nota de apoyo** para quien expone.
- Un botón para **descargar ese guion en PDF**.

## Orden de participación

| # | Quién | Diapositivas | Tiempo |
|---|---|---|---|
| 1 | Dilan | 1–4 · Portada, ¿Qué es la escritura?, Antes y después | ≈1 min |
| 2 | Samuel | 5–8 · Contexto, ¿Por qué allí y entonces?, ¿Qué escribían? | ≈2 min |
| 3 | Valeria | 9–11 · Protagonistas, La casa de las tablillas, Desarrollo | ≈2 min |
| 4 | Dilan | 12–14 · Impacto, Impacto en el tiempo | ≈1 min |
| 5 | Camila | 15–16 · Sección 04, Legado | ≈2 min |
| 6 | Leimar | 17–18 · Importancia, Cierre | ≈2 min |

Total: ≈10 minutos.

## Estructura

```
index.html      la página completa (imágenes incluidas en el propio archivo)
assets/         spritesheet y recortes originales del pixel art
pdf/            un PDF por integrante + el completo
src/            fuentes para regenerar la página
```

## Regenerar la página

El contenido de los guiones vive en `src/content.py`; la maqueta, en `src/page.template.html`.

```bash
cd src
python3 build.py
```

El script incrusta las imágenes en base64 y escribe el HTML final.
